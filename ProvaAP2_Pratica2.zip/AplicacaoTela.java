package ProvaAP2;

public class AplicacaoTela
{
   public static void main(String[] args) {
 new TelaCovid();
 }
}
